import 'dart:convert';
import 'package:asyncprogfutureflutter/models/post_model.dart';
import 'package:http/http.dart' as http;

class PostsService {
  Future<PostModel> fetchPosts() async {
    var url = Uri.https('jsonplaceholder.typicode.com', 'posts/10');
    var response = await http.get(url);
    if (response.statusCode == 200) {
      // when async get call is a success
      var data = PostModel.fromJson(
        jsonDecode(response.body),
      );
      return data;
    } else {
      return null;
    }
  }
}
