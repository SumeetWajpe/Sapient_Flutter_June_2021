import 'package:flutter_test/flutter_test.dart';
import 'package:unittesting/utils/time_helper.dart';

main() {
  // Arrange - Initialization of variable
  // Act - Calling Of Method
  // Assert - (Check)
  // test("Test true is equal to true", () {
  //   bool expectedBoolValue = true;

  //   expect(expectedBoolValue, true);
  // });

  // test("TimeHelper should return Morning", () {
  //   expect(TimeHelper.getTimeOfTheDay(), "morning");
  // });

  group("Testing different times returned by TimeHelper", () {
    test("TimeHelper should return night", () {
      // Arrange
      DateTime currTime = DateTime(2021, 6, 23, 5);

      //Act
      String returnedValue = TimeHelper.getTimeOfTheDay(currTime);

      //Assert
      expect(returnedValue, "night");
    });
    test("TimeHelper should return night", () {
      // Arrange
      DateTime currTime = DateTime(2021, 6, 23, 14);

      //Act
      String returnedValue = TimeHelper.getTimeOfTheDay(currTime);

      //Assert
      expect(returnedValue, "afternoon");
    });
  });
}
