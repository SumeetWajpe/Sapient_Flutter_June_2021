import 'package:flutter/material.dart';
import 'package:unittesting/utils/time_helper.dart';

class GreetingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                "images/${TimeHelper.getTimeOfTheDay(DateTime.now())}.jpg"), //Time Helper
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Good ${TimeHelper.getTimeOfTheDay(DateTime.now())}", // Time Helper
              style: TextStyle(
                  fontSize: 50.0,
                  color: Colors.blue[700],
                  fontWeight: FontWeight.bold),
            )
          ],
        ),
      ),
    );
  }
}
