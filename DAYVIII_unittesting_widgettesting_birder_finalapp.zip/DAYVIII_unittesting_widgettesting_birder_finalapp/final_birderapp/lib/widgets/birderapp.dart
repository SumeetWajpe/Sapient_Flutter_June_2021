import 'package:birderapp/models/birdlist_changenotifier.dart';
import 'package:birderapp/screens/add_new_bird_screen.dart';
// import 'package:birderapp/screens/localization_bird.dart';
// import 'package:birderapp/widgets/bird_list_with_listview.dart';
import 'package:birderapp/widgets/bird_list_with_listviewbuilder.dart';
import 'package:birderapp/widgets/birder_drawer.dart';
// import 'package:birderapp/widgets/birdcount.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class BirderApp extends StatelessWidget {
  static final String routeName = "/home";
  @override
  Widget build(BuildContext context) {
    return Consumer<BirdListChangeNotifier>(
      builder: (context, birdCNinstance, child) => Scaffold(
        drawer: BirderDrawer(),
        appBar: AppBar(
          title: Text('Birder App'),
          centerTitle: true,
          // backgroundColor: Colors.teal[700],
          actions: <Widget>[
            Padding(
              padding: const EdgeInsets.only(right: 20.0),
              child: InkWell(
                onTap: () => navigateToAddNewBirdScreen(context),
                child: Icon(Icons.add),
              ),
            )
          ],
        ),
        // body: BirdListWithListView(),
        body: BirdListWithListViewBuilder(),
        // body: LocalizedBird(),
        floatingActionButton: birdCNinstance.listofbirds.length < 5
            ? FloatingActionButton(
                onPressed: () {
                  // Navigate to AddNewBirdScreen !
                  navigateToAddNewBirdScreen(context);
                },
                // backgroundColor: Colors.teal[700],
                child: Icon(Icons.add),
              )
            : null,
      ),
    );
  }

  void navigateToAddNewBirdScreen(BuildContext context) async {
    // var result = await Navigator.push<String>(
    //   context,
    //   MaterialPageRoute(
    //     builder: (context) => AddNewBird(),
    //   ),
    // );

    // If routes are defined

    //Navigator.pushNamed<String>(context, AddNewBird.routeName);
    var result = await Navigator.pushNamed(context, AddNewBird.routeName);

    if (result == "success") {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Bird added successfully !'),
        ),
      );
    }
  }
}
