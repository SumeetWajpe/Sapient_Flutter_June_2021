import 'package:birderapp/models/birdlist_changenotifier.dart';
import 'package:birderapp/screens/add_new_bird_screen.dart';
import 'package:birderapp/screens/bird_splash_screen.dart';
import 'package:birderapp/screens/localization_bird.dart';
// import 'package:flutter_localizations/flutter_localizations.dart;
import 'package:flutter_gen/gen_l10n/app_localization.dart';
import 'package:birderapp/widgets/birderapp.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    ChangeNotifierProvider(
      create: (_) => BirdListChangeNotifier(),
      child: MaterialApp(
        supportedLocales: AppLocalizations.supportedLocales,
        localizationsDelegates: AppLocalizations.localizationsDelegates,
        theme: ThemeData(
          primarySwatch: Colors.teal,
          textTheme: ThemeData.light().textTheme.copyWith(
                headline1: TextStyle(
                    color: Colors.black,
                    fontFamily: 'Pacifico',
                    fontSize: 20.0),
                headline4: TextStyle(
                  color: Colors.grey[800],
                  fontSize: 20.0,
                ),
              ),
        ),
        home: BirdSplashScreen(),
        // OR
        // initialRoute: "/localize",
        routes: {
          BirderApp.routeName: (ctx) => BirderApp(),
          AddNewBird.routeName: (ctx) => AddNewBird(),
          LocalizedBird.routeName: (ctx) => LocalizedBird()
        },
      ),
    ),
  );
}

// Row(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: <Widget>[
//               Image(
//                 width: 100.00,
//                 image: AssetImage('images/hornbill.jpg'),
//               ),
//               Padding(
//                 padding: const EdgeInsets.only(
//                   left: 10.0,
//                 ),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: <Widget>[
//                     Text(
//                       'Hornbill',
//                       style: TextStyle(
//                         fontSize: 30.0,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                     Text(
//                       'Bucerotidae',
//                       style: TextStyle(
//                         color: Colors.grey[700],
//                         fontSize: 18.0,
//                         fontFamily: 'Pacifico',
//                         fontStyle: FontStyle.italic,
//                       ),
//                     )
//                   ],
//                 ),
//               ),
//               Text(
//                 'Delete',
//                 style: TextStyle(color: Colors.red,),
//               )
//             ],
//           ),
