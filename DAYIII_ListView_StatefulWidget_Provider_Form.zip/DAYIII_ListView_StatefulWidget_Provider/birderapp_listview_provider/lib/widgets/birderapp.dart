import 'package:birderapp/models/birdlist_changenotifier.dart';
import 'package:birderapp/widgets/bird_list_with_listview.dart';
// import 'package:birderapp/widgets/birdcount.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class BirderApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => BirdListChangeNotifier(),
      child: MaterialApp(
        home: Scaffold(
          appBar: AppBar(
            title: Text('Birder App'),
            centerTitle: true,
            backgroundColor: Colors.teal[700],
          ),
          body: BirdListWithListView(),
        ),
      ),
    );
  }
}
