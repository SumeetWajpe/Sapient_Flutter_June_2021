import 'package:birderapp/models/birdmodel.dart';
import 'package:flutter/material.dart';

class AddNewBird extends StatefulWidget {
  @override
  _AddNewBirdState createState() => _AddNewBirdState();
}

class _AddNewBirdState extends State<AddNewBird> {
  String _txtName;
  String _txtScientificName;
  String _txtImageUrl;
  String _txtId;
  BirdModel _newbird;

  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();

  Widget _buildBirdId() {
    return TextFormField(
      keyboardType: TextInputType.number,
      validator: (String value) {
        if (value.isEmpty) {
          return "Id Required !";
        }
        return null;
      },
      decoration: InputDecoration(labelText: 'Id:'),
      onSaved: (String value) {
        _txtId = value;
      },
    );
  }

  Widget _buildBirdName() {
    return TextFormField(
      decoration: InputDecoration(labelText: 'Name:'),
      validator: (String value) {
        if (value.isEmpty) {
          return "Name Required !";
        }
        return null;
      },
      onSaved: (String value) {
        _txtName = value;
      },
    );
  }

  Widget _buildBirdScientificName() {
    return TextFormField(
      decoration: InputDecoration(labelText: 'Scientific Name:'),
      validator: (String value) {
        if (value.isEmpty) {
          return "Scientific Name Required !";
        }
        return null;
      },
      onSaved: (String value) {
        _txtScientificName = value;
      },
    );
  }

  Widget _buildBirdImageUrl() {
    return TextFormField(
      decoration: InputDecoration(labelText: 'Image Url:'),
      validator: (String value) {
        if (value.isEmpty) {
          return "Image Url Required !";
        }
        return null;
      },
      onSaved: (String value) {
        _txtImageUrl = value;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.all(20.0),
        child: Form(
          key: _formkey,
          child: Column(
            children: <Widget>[
              _buildBirdId(),
              _buildBirdName(),
              _buildBirdScientificName(),
              _buildBirdImageUrl(),
              ElevatedButton(
                onPressed: () {
                  if (!_formkey.currentState.validate()) {
                    return;
                  }

                  // save the bird

                  _formkey.currentState.save();
                  _newbird = BirdModel(
                      id: int.parse(_txtId),
                      name: _txtName,
                      scientificName: _txtScientificName,
                      imageUrl: _txtImageUrl);
                },
                child: Text('Add new bird'),
              )
            ],
          ),
        ),
      ),
    );
  }
}
