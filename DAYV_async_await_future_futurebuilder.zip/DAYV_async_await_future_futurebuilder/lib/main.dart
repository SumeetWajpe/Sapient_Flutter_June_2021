import 'package:asyncprogfutureflutter/models/post_model.dart';
import 'package:asyncprogfutureflutter/services/post_service.dart';
import 'package:asyncprogfutureflutter/widgets/posts_with_future_builder.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // home: Posts(title: 'All Posts'),
      home: Scaffold(
        appBar: AppBar(
          title: Text('Posts With Future Builder'),
        ),
        body: Center(child: PostsFutureBuilder()),
      ),
    );
  }
}

class Posts extends StatelessWidget {
  final String title;
  final PostsService _srvObject = PostsService();
  Posts({this.title});
  List<PostModel> lisofposts;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Container(
        child: Column(
          children: [
            Text(title),
            ElevatedButton(
              onPressed: () {
                // Displays one single record
                // Future<PostModel> futurePostModelObj =
                //     _srvObject.fetchPostsById(10);
                // futurePostModelObj.then(
                //   (value) =>
                //       print('Displaying data from Widget -> ${value.title}'),
                // );

                // List of data
                print('Waiting for data !');
              },
              child: Text('Get Post'),
            )
          ],
        ),
      ),
    );
  }
}
