class BirdModel {
  final int id;
  final String name;
  final String scientificName;
  final String imageUrl;
  final String info;
  int likes;

  BirdModel(
      {this.id,
      this.name,
      this.scientificName,
      this.imageUrl,
      this.likes = 0,
      this.info});
}
