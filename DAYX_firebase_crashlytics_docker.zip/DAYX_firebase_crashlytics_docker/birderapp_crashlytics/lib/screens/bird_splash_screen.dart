import 'dart:async';

import 'package:birderapp/widgets/birderapp.dart';
import 'package:flutter/material.dart';

class BirdSplashScreen extends StatefulWidget {
  @override
  _BirdSplashScreenState createState() => _BirdSplashScreenState();
}

class _BirdSplashScreenState extends State<BirdSplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(
      Duration(seconds: 10),
      () => Navigator.of(context).pushReplacementNamed(
        BirderApp.routeName,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: Center(
          child: Image.network(
              "https://i.pinimg.com/originals/29/55/81/295581b0bf78810a2e2ea84728f8de14.gif"),
        ));
  }
}
