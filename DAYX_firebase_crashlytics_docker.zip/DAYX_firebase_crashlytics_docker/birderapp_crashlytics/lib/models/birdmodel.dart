import 'package:flutter/foundation.dart';

class BirdModel {
  final int id;
  final String name;
  final String scientificName;
  final String imageUrl;
  final String info;
  int likes;

  BirdModel(
      {@required this.id,
      @required this.name,
      @required this.scientificName,
      @required this.imageUrl,
      @required this.likes,
      @required this.info});

  factory BirdModel.fromJSON(Map<String, dynamic> jsonData) {
    return BirdModel(
      id: jsonData["id"],
      name: jsonData["name"],
      scientificName: jsonData["scientificName"],
      imageUrl: jsonData["imageUrl"],
      info: jsonData["info"],
      likes: jsonData["likes"],
    );
  }
}
