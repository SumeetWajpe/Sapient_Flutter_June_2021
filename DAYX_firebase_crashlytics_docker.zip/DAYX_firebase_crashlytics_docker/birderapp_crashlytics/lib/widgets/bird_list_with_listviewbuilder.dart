import 'package:birderapp/models/birdlist_changenotifier.dart';
// import 'package:birderapp/screens/bird_details_screen.dart';
import 'package:birderapp/screens/bird_details_with_sliver_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class BirdListWithListViewBuilder extends StatefulWidget {
  @override
  _BirdListWithListViewBuilderState createState() =>
      _BirdListWithListViewBuilderState();
}

class _BirdListWithListViewBuilderState
    extends State<BirdListWithListViewBuilder> {
  @override
  void initState() {
    super.initState();
    Provider.of<BirdListChangeNotifier>(context, listen: false).getAllBirds();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<BirdListChangeNotifier>(
      builder: (_, birdlistCNInstance, __) => ListView.builder(
          itemCount: birdlistCNInstance.listofbirds.length,
          itemBuilder: (BuildContext context, int index) {
            return GestureDetector(
              onHorizontalDragEnd: (_) {
                // print('U dragged !');
                birdlistCNInstance.deleteABird(birdlistCNInstance.listofbirds[
                    index]); // will change (comes from ChangeNotifier)
              },
              child: Card(
                elevation: 10,
                child: ListTile(
                  leading: GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => BirdDetailsWithSliver(
                              theBird: birdlistCNInstance.listofbirds[index],
                            ),
                          )
                          // MaterialPageRoute(
                          //   builder: (context) => BirdDetails(
                          //     theBird: birdlistCNInstance.listofbirds[index],
                          //   ),
                          // ),
                          );
                    },
                    child: Hero(
                      tag:
                          'birdHeroFly-${birdlistCNInstance.listofbirds[index].id}',
                      child: Image(
                        width: 100.0,
                        fit: BoxFit.fitWidth,
                        image: NetworkImage(
                            birdlistCNInstance.listofbirds[index].imageUrl),
                      ),
                    ),
                  ),
                  title: Text(
                    birdlistCNInstance.listofbirds[index].name,
                    style: Theme.of(context).textTheme.headline1,
                  ),
                  subtitle: Text(
                    birdlistCNInstance.listofbirds[index].scientificName,
                    style: TextStyle(fontSize: 18.0),
                  ),
                  trailing: InkWell(
                    child: Icon(
                      Icons.delete,
                      color: Theme.of(context).primaryColor,
                    ),
                    onTap: () {
                      // print('U tapped ! But have u tapped ur potential ?');
                      birdlistCNInstance
                          .deleteABird(birdlistCNInstance.listofbirds[index]);
                    },
                  ),
                  // trailing: Column(
                  //   children: <Widget>[
                  //     Text(bird.likes.toString()),
                  //     InkWell(
                  //       child: Icon(
                  //         Icons.thumb_up_outlined,
                  //         color: Colors.blue,
                  //       ),
                  //       onTap: () {
                  //         setState(() {
                  //           bird.likes += 1;
                  //           print(bird.likes);
                  //         });
                  //       },
                  //     )
                  //   ],
                  // ),
                ),
              ),
            );
          }),
    );
  }
}
