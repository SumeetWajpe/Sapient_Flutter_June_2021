package com.example.birderapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
