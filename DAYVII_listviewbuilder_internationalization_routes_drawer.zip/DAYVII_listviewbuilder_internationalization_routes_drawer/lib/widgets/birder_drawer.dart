import 'package:birderapp/models/drawer_menu.dart';
import 'package:birderapp/screens/add_new_bird_screen.dart';
import 'package:birderapp/screens/localization_bird.dart';
import 'package:birderapp/widgets/birderapp.dart';
import 'package:flutter/material.dart';

class BirderDrawer extends StatelessWidget {
  final List<MenuItem> menuItems = [
    MenuItem(
      icon: Icons.home,
      title: 'Home',
      route: BirderApp.routeName,
    ),
    MenuItem(
      icon: Icons.add,
      title: 'Add New Bird',
      route: AddNewBird.routeName,
    ),
    MenuItem(
      icon: Icons.language,
      title: 'Localized Birds ',
      route: LocalizedBird.routeName,
    )
  ];

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          Stack(
            children: [
              Container(
                height: 200.0,
                decoration: BoxDecoration(color: Theme.of(context).accentColor),
              ),
              Container(
                margin: EdgeInsets.all(25.0),
                child: Center(
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 50.0,
                        backgroundImage: NetworkImage(
                            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSEYrEEugxr-zaWYG6QXMFnnRBQ0CT7ff5C_G_aesmvfXSVYHnpzbNBk8vkHV7O-5THvvg&usqp=CAU'),
                      ),
                      Text(
                        'Birder\'s App',
                        style: Theme.of(context).textTheme.headline1,
                      )
                    ],
                  ),
                ),
              )
            ],
          )

          // ListViewBuilder
        ],
      ),
    );
  }
}
