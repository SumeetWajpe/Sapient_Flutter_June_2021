import 'package:flutter/material.dart';

class BirdListWithListView extends StatelessWidget {
  List<String> listofbirds = ["Hornbill", "Humming Bird", "Kingfisher"];

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        ...listofbirds.map(
          (bird) => Text(bird),
        ),
      ],
    );
  }
}
// ListTile -> leading , title, subtitle , trailing