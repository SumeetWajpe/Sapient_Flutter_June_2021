import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
          appBar: AppBar(
            title: Text('Hello Flutter'),
            backgroundColor: Colors.teal[700],
          ),
          body: Row(
            // mainAxisSize: MainAxisSize.min,
            // mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Container(
                // height: 100.0,
                width: 100.0,
                color: Colors.yellow,
                child: Text('Container 1'),
              ),
              Container(
                // height: 100.0,
                width: 100.0,
                color: Colors.red,
                child: Text('Container 2'),
              ),
              Container(
                // height: 100.0,
                width: 100.0,
                color: Colors.green,
                child: Text('Container 3'),
              ),
            ],
          )),
    ),
  );
}

// body: Center(
//           child: Image(
//             image: NetworkImage(
//                 'https://tech.pelmorex.com/wp-content/uploads/2020/10/flutter.png'),
//           ),
//         ),

// Image(
//                 image: NetworkImage(
//                     'https://tech.pelmorex.com/wp-content/uploads/2020/10/flutter.png'),
//               ),
//               Text(
//                   'Flutter is an open-source UI software development kit created by Google. It is used to develop cross platform applications for Android, iOS, Linux, Mac, Windows, Google Fuchsia, and the web from a single codebase.'),
