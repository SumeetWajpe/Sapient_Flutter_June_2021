void main() {
  print('The addition is : ${Add(10, 20)}');
  print('The addition is : ${Addition(40, 20)}');

  // printBooks('Dr. APJ Abdul Kalam', 'Wings Of Fire', 300); // Optional Positional Parameters
  printBooks(title: 'Playing It My Way', author: 'Sachin Tendulkar');
}

int Add(int x, int y) {
  return x + y;
}

// Function Expression / Fat Arrow Functions / Short Hand
int Addition(int x, int y) => x + y;

// Parameters
// Positional
// Optional,
//Named Parameters
// Optional Positional Parameters
// void printBooks(String author, String title,
//     [int noOfPages = 100, String publisher = 'Packt']) {
//   print(
//       'The book ${title} is written by ${author} having ${noOfPages} pages !');
// }

// Optional Named Parameters
void printBooks({String author = "Unknown", String title = "Unknown"}) {
  print('The book ${title} is written by ${author} !');
}
