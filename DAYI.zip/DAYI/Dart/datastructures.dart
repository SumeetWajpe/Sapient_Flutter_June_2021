void main() {
  var cars = [
    "BMW",
    "AUDI",
    "Hyundai"
  ]; // An implicit List (not strongly typed by default)
  cars.add('Maruti'); // add method from List

  List<String> stringCars = [];
  // stringCars.add(100); // Error !

  // for (var car in cars) {
  //   print(car);
  // }

  print(cars[1]);
  print(cars.last);

  var listOfEvenNumbers = [1, 2, 3, 4, 5].where((n) => n.isEven);
  for (var evenNos in listOfEvenNumbers) {
    print(evenNos);
  }

  // Map -> key / value
  Map<String, String> fruits = {"guava": "green", "apple": "red"};

  // fruits.forEach((key, value) {
  //   "Key : ${key} , Value : ${value}";
  // });

  // OR

  //fruits.forEach((key, value) => print("Key : ${key} , Value : ${value}"));

  for (String key in fruits.keys) {
    print(key);
  }

  print(fruits['apple']);

  List<Map<String, String>> listofmapsofcitiesandstates = [
    {"Pune": "Maharashtra", "Noida": "Uttar Pradesh"},
    {"Goa": "Goa"},
    {"Gurgaon": "Haryana"}
  ];

  for (var listitem in listofmapsofcitiesandstates) {
    listitem.forEach((key, value) {
      print("Key : ${key} , Value : ${value}");
    });
  }
}

// Create a "List" of "map". Map-> city and state
// Iterate through the "List" and print cities and states
