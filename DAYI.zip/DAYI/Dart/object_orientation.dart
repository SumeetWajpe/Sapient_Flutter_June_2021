main() {
  // var carOne = Car();
  // carOne.name = 'i20';
  // carOne.speed = 100;
  // print('The car ${carOne.name} is running at ${carOne.speed} kmph !');

  // var carTwo = Car('i20', 200);
  // print('The car ${carTwo.name} is running at ${carTwo.speed} kmph !');

  // var carThree = Car(speed: 200, name: 'i30');
  // print('The car ${carThree.name} is running at ${carThree.speed} kmph !');

  // var carFour = Car.getCarInstance();

  // var carFive = Car.getCarInstanceWithNameAndSpeed('Creta', 300);
  // var carSix = Car.getCarInstanceWithNameSpeedAndId('i10', 100, 1);

  // var carSeven = Car();
  // carSeven.accelerate();

  // var pOne = Product();
  // pOne.Title = "Laptop"; // setter | mutator
  // print(pOne.Title); // getter | accessor

  var mgr = Manager('Anil', 'Acccenture', 50000, 4000);
  print('The Salary is : ${mgr.CalculateSalary()}');
}

// attributes & behaviours
class Car {
  String? name; // instance variable
  int? speed;
  int? id;
  // Default ctor !
  // Car() {
  //   this.name = 'Unknown';
  //   this.speed = 0;
  // }

  // Car(String name, int speed) {
  //   this.name = name;
  //   this.speed = speed;
  // }

  // OR
  // Parameterized Ctor (short-cut way)
  // Car(this.name, this.speed);

  // Optional positional parameters
  // Car([this.name = 'Unknown', this.speed = 0]);

  // Optional Named Parameters
  // Car({this.name = 'Unknown', this.speed = 0});

  // Named Constructor
  // Car.getCarInstance();

// Named Constructor - accepts parameters
  //Car.getCarInstanceWithNameAndSpeed(this.name, this.speed);
  //Car.getCarInstanceWithNameSpeedAndId(this.name, this.speed, this.id);

  void accelerate() {
    print('VVRRRROOOMMMMM....');
  }
}

class Product {
  // final int id = 1;
  String _title =
      'Unknown'; // public for current dart file but private for other dart files

  // String get Title {
  //   return _title;
  // }
  // OR
  String get Title => _title;

  // void set Title(String input_value) {
  //   if (input_value != '') {
  //     this._title = input_value;
  //   }
  // }

  void set Title(String input_value) => this._title = input_value;
}

class Employee {
  String name;
  String company;
  double salary;

  Employee({this.name = '', this.company = '', this.salary = 0});

  double CalculateSalary() => this.salary;
}

class Manager extends Employee {
  double stocks = 20000.00;
  Manager(String name, String company, double salary, double stocks)
      : super(name: name, company: company, salary: salary) {
    this.stocks = stocks;
  }

  @override
  double CalculateSalary() => super.CalculateSalary() + stocks;
}
