void main() {
  // print('Running dart from VS Code !');
  // var x = 10; // type inference
  // x = 'Hello'; // Error ! (Strong typing)
  int x;
  x = 20;
  //final & const
  final double
      length; // can be assigned a value at runtime (mostly useful with classes)
  length = 100;
  print('Length * 3 is : ${length * 3}');

  const double PI = 3.14;
  print('The value of PI is : ${PI}');
}
